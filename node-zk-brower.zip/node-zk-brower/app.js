/**
/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 *
 * node-zk-browser
 * author :dennis (killme2008@gmail.com)
 *
 */

 //express.js是nodejs的一个MVC开发框架

 //引入express模块

var express = require('express');
require('express-namespace');
/*
require()是node.js提供的函数，可以让你引入其他模块以调用模块的函数和变量，默认下node.js会在$NODE_PATH和目前js所在目录下的node_modules文件夹下去寻找模块，express.js继承自connect模块，所以如果你的node_modules文件夹下没有connect模块也是不行的。
*/
var path=require('path');
var fs=require('fs');
var util=require('util');
var ZkClient=require('./zk.js').ZkClient;

var port = process.env.ZK_BROWSER_PORT || 4000;
var host = process.env.ZK_HOST || '10.16.10.76:2181';
var zkclient = new ZkClient("10.16.10.76:2181");
var users = JSON.parse(fs.readFileSync(path.join(__dirname,'user.json'), 'utf8'));
var app = express();

process.on('uncaughtException', function (err) {
  console.error('Caught exception: ' + err);
});


// Configuration
app.configure(function(){

    app.set('views', __dirname + '/views');//设置views路径和模板
	//上面两行是设置views文件夹，即模板文件夹
	//__dirname是node.js里面的全局变量，即取得执行的js所在的路径
	//另外__dirname是目前执行的js文件名

    app.set('view engine', 'ejs');//设置express.js所使用的render engine，使用EJS(embedded javascript)js模板

	app.use(express.cookieParser());//这个插件通常当作中间件使用，app.use(cookieParser()), 这样就可以处理每一个请求的cookie。
	//Cookie是浏览器（User Agent）访问一些网站后，这些网站存放在客户端的一组数据，用于使网站等跟踪用户，实现用户自定义功能。

    app.use(express.session({ secret: "node zk browser" }));

    //Session 是存放在服务器端的类似于HashTable结构（每一种web开发技术的实现可能不一样，下文直接称之为HashTable）来存放用户数据，
    //当浏览器 第一次发送请求时，服务器自动生成了一个HashTable和一个Session ID用来唯一标识这个HashTable，并将其通过响应发送到浏览器。
    //当浏览器第二次发送请求，会将前一次服务器响应中的Session ID放在请求中一并发送到服务器上，服务器从请求中提取出Session ID，
    //并和保存的所有Session ID进行对比，找到这个用户对应的HashTable。

    app.use(express.bodyParser());
    //express.bodyParser()是Connect内建的middleware（中间件），设置此处可以将client提交过来的post请求放入request.body中。

	app.use(express.methodOverride());
    //express.methodOverride()也是Connect内建的中间件，可以协助处理POST请求伪装PUT、DELETE和其他HTTP methods。

	app.use(app.router);//app.router()是route requests，但express.js的官方文件是这句可有可无

	app.use(express.static(__dirname + '/public'));
	//express.static()也是一个Connect内建的中间件，来处理静态的requests，例如css、js、img文件等。
	//所以static()里面指定的文件夹中的文件会直接作为静态资源吐出来。
});

app.configure('development', function(){
  app.use(express.errorHandler({ dumpExceptions: true, showStack: true }));
  //express.errorHandler()是Connect内建的中间件来协助处理例外情况。
  //这里也揭露了app.configure()的另一用法，第一个参数是node.js的环境设定，如此我们就可以设定在不同的执行环境下使用不同的dump。
});

app.configure('production', function(){
  app.use(express.errorHandler());//与上述同理，只是环境不同
});

// Routes
app.get('/', function(req, res){
    res.redirect("/node-zk");
    //ajax请求到node后台之后，res.redirect做的是服务器的重新定向，跳转
});

app.namespace("/node-zk",function(){

    //index
    app.get('/', function(req, res){
        res.render('index', { });
        //get请求根目录则调用views文件夹中的index模板
    });

    //display tree
    app.get('/tree', function(req, res){
        var path=req.query.path || "/news-recommendation";
        res.render('tree', {layout:false,'path':path, 'host':host});
    });

    //login
    app.post("/login",function(req,res){
        var user=req.body.user;
        if(users[user.name]==user.password){
            req.session.user=user.name
            req.session.cookie.maxAge=5*60*1000;
        }
        res.redirect(req.header('Referer'));
    });

    //delete
    app.post("/delete",function(req,res){
        if(req.session.user){
            var path=req.body.path;
            var version=Number(req.body.version);
            zkclient.zk.a_delete_(path,version,function(rc,err){
                if(rc!=0)
                    res.send(err);
                else
                    res.send("Delete ok");
            });
        }else{
            res.send("Please logon");
        }
    });

    //create view
    app.get("/create",function(req,res){
        res.render("create",{layout:false,user: req.session.user});
    });

    //create
    app.post("/create",function(req,res){
        if(req.session.user){
            var path=req.body.path;
            var data=req.body.data;
            var flag=Number(req.body.flag);
            zkclient.zk.a_create(path,data,flag,function(rc,err,path){
                if(rc!=0)
                    res.send(err);
                else
                    res.send("Create ok");
            });
        }else{
            res.send("Please logon");
        }
    });

    //edit
    app.post("/edit",function(req,res){
        if(req.session.user){
            var path=req.body.path;
            var new_data=req.body.new_data;
            var version=Number(req.body.version);
            zkclient.zk.a_set(path,new_data,version,function(rc,err,stat){
                if(rc!=0){
                    res.send(err);
                }else
                    res.send("set ok");
            });
        }else{
            res.send("Please logon");
        }
    });

    //query data
    app.get("/get",function(req,res){
        var path=req.query.path || "/";
        zkclient.zk.a_get(path,null,function(rc,err,stat,data){
            if(rc!=0){
                res.send(err);
            }else{
                res.render("data",{ layout: false, 'stat':stat,'data':data,'path':path,'user': req.session.user});
            }
        });
    });

    //query children
    app.get('/children',function(req,res){
        var parenPath=req.query.path || '/effect/rec';
        zkclient.zk.a_get_children(parenPath,null,function(rc,error,children){
            res.header("Content-Type","application/json");
            var result=[];
            if(rc==0){
                children.forEach(function(child){
                    realPath=path.join(parenPath,child);
                    result.unshift({
                        attributes:{"path":realPath,"rel":"chv"},
                        data:{
                            title : child,icon:"ou.png", attributes: { "href" : ("/node-zk/get?path="+realPath) }
                        },
                        state:"closed"
                    });
                });
            }
            res.send(result);
        });
    });
});

app.listen(port);//启动监听窗口
console.log("Express server listening on port %d", port);
